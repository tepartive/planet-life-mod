
function veryGoodSceneName() {

	// changeScene() displays new text and image
	changeScene(
		"Hello, do you want some.... <span style='color:#00ffff'>STARDUST?</span>",
		"stardust"
	);

	// createGoButton() makes a new button with text, image and the scene that it will go to when clicked
	createGoButton(
		"yes please!",
		"stardust",
		veryBadSceneName
	);

	createGoButton(
		"nnnno, not right now;",
		"no",
		goRoot
	);

}


function veryBadSceneName() {

	changeScene(
		"well here! (just dont tell anybody)",
		"stardust"
	);

updateState('stardust', state.stardust + 100);

	createGoButton(
		"thank you!",
		"planet",
		veryGoodSceneName
	);

}

