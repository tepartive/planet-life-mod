var isGamePaused = false;
var mobile = false;
var coolMath = false;
var censoredWords = false;
var aboutPromotion = true;
var disableExport = false;
var scrollEnabled = false;